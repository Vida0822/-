package days28;

/**
 * @author ♈ k§nik
 * @date 2023. 3. 7. - 오후 12:40:49
 * @subject 
 * @content 
 */
public class Ex02_09 {

	public static void main(String[] args) {
		// 1. com.util 패키지 + FileUtil.java   나중에 프로젝트 할때 확장자, 순수파일명, 파일명, 폴더 삭제..

	} // main

} // class
